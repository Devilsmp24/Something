import {
  ChannelType,
  MessageFlags,
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  ButtonStyle,
  ActionRowBuilder,
  ButtonBuilder,
} from "discord.js";

export default {
  data: new SlashCommandBuilder()
    .setName("sendexembed")
    .setDescription("Sends exchange embed")
    .addChannelOption((option) =>
      option
        .setName("channel")
        .setDescription("The channel to send the embed to")
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  run: async ({ interaction, client }) => {
    const config = client.config;
    const channel =
      interaction.options.getChannel("channel") || interaction.channel;

    if (!channel.isTextBased()) {
      return interaction.reply({
        content: "Please select a valid text channel.",
        flags: MessageFlags.Ephemeral,
      });
    }

    const embed = new EmbedBuilder()
      .setTitle(config.exchangeEmbed.title)
      .setDescription(config.exchangeEmbed.description)
      .setColor(config.exchangeEmbed.color)
      .setThumbnail(client.user.displayAvatarURL());

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("create_ticket")
        .setLabel("Create Ticket")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId("exchange_rate")
        .setLabel("Rate")
        .setStyle(ButtonStyle.Primary)
    );

    try {
      await channel.send({
        embeds: [embed],
        components: [buttons],
      });
      return interaction.reply({
        content: `Exchange embed sent to ${channel}.`,
        flags: MessageFlags.Ephemeral,
      });
    } catch (error) {
      console.error("Error sending exchange embed:", error);
      return interaction.reply({
        content: "Failed to send the exchange embed.",
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
