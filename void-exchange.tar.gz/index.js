import config from "./config.js";
import { Client, GatewayIntentBits } from "discord.js";
import { CommandKit } from "commandkit";
import { fileURLToPath } from "url";
import axios from "axios";
import path from "path";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.config = config;

const __dirname = path.dirname(fileURLToPath(import.meta.url));

new CommandKit({
  client,
  commandsPath: path.join(__dirname, "commands"),
  eventsPath: path.join(__dirname, "events"),
  skipBuiltInValidations: true,
  bulkRegister: true,
});

// function fetchExchangeRates() {
//   return axios
//     .get(
//       "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=inr,usd,bdt,npr,pkr"
//     )
//     .then((response) => response.data)
//     .catch((error) => {
//       console.error("Error fetching exchange rates:", error);
//       return {};
//     });
// }

// console.log("Fetching exchange rates...");
// fetchExchangeRates()
//   .then((rates) => {
//     console.log("Exchange rates fetched successfully:", rates);
//     client.exchangeRates = rates;
//   })
//   .catch((error) => {
//     console.error("Failed to fetch exchange rates:", error);
//     process.exit(1);
//   });

client.login(config.token).catch((err) => {
  console.error("Failed to login:", err);
  process.exit(1);
});
