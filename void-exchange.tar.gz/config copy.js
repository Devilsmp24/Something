export default {
  token:
    "MTM4NzMxODA2MDY1NDAwMjIxNQ.GyEXca.1NiA5-J2kHBFK7QQ-FrTgIa-1UmIKB87g",
  exchangeEmbed: {
    title: "Void Exchange",
    description: `**Click a button below to get started:**
・**Rate** — Check current exchange rates
・**Create Ticket** — Open a Exchange ticket

**__Important Notes:__**
↣ Third-party payments are strictly prohibited.
↣ We do **not** cover transaction fees.
↣ Please check https://discord.com/channels/1386970517252210830/1386992051542949929/1387042761596993550 before starting an exchange.`,
    color: 0x0099ff, //This is a hex color code
  },
  guildId: "1386970517252210830",
  exchangerRoleId: "1386992031146053663",
  exchangeRates: [
    {
      key: "inrExchange",
      categoryId: "1386992150595633182",
      emoji: "<:inr:1387325108258869429>",
      title: "INR Exchanges",
      isPercentage: false,
      rates: {
        "INR To Crypto": "₹90/$ | Any Amount",
        "Crypto To INR": "₹88/$ | Any Amount",
      },
      raw: { i2c: 90, c2i: 88 },
      apps: ["PhonePe", "Paytm", "GPay", "Fampay"], // ⬅️ Added this
      receiveOptions: {
        Crypto: [
          "Litecoin",
          "Bitcoin",
          "Solana",
          "Ethereum",
          "USDT",
          "Tron",
          "Binance",
        ],
      },
    },
    {
      key: "cryptoExchange",
      categoryId: "1386992150595633182",
      emoji: "<:crypto:1387325330041212989>",
      title: "Crypto Exchanges",
      isPercentage: true,
      rates: {
        "Crypto To Crypto": "2% Fees",
      },
      raw: { c2c: 2 },
      apps: ["USDT", "BTC", "ETH"],
      receiveOptions: {
        Crypto: ["INR"],
      },
    },
    {
      key: "paypalExchange",
      categoryId: "1386992150595633182",
      emoji: "<:paypal:1387325528352100463>",
      title: "PayPal Exchanges",
      isPercentage: true,
      rates: {
        "PayPal To Crypto": "10% Fees",
        "Crypto To PayPal": "0% Fees",
      },
      raw: { p2c: 10, c2p: 0 },
      apps: ["PayPal Personal", "PayPal Business"],
      receiveOptions: {
          Crypto: ["USDT", "Litecoin"],
      },
    },
    {
      key: "cashappExchange",
      categoryId: "1386992150595633182",
      emoji: "<:cashapp:1387325707843010590>",
      title: "Cashapp Exchanges",
      isPercentage: true,
      rates: {
        "CashApp To Crypto": "12% Fees | Any Amount",
        "Crypto To Cashapp": "0% Fees | Any Amount",
      },
      raw: { ca2c: 12, c2ca: 0 },
      apps: ["Cash App"],
      receiveOptions: {
          Crypto: ["Litecoin"],
      },
    },
    {
      key: "nprExchange",
      categoryId: "1386992150595633182",
      emoji: "<:npr:1387325909161480212>",
      title: "NPR Exchanges",
      isPercentage: false,
      rates: {
        "NPR To Crypto": "148/$ | Any Amount",
        "Crypto To NPR": "126/$ | Any Amount",
      },
      raw: { n2c: 148, c2n: 126 },
      apps: ["eSewa", "IME Pay", "Khalti"],
      receiveOptions: {
          Crypto: ["USDT","Litecoin"],
      },
    },
    {
      key: "bdtExchange",
      categoryId: "1386992150595633182",
      emoji: "<:bdt:1387326113394458754>",
      title: "BDT Exchanges",
      isPercentage: false,
      rates: {
        "BDT To Crypto": "138/$ | Any Amount",
        "Crypto To BDT": "110/$ | Any Amount",
      },
      raw: { b2c: 138, c2b: 110 },
      apps: ["Bkash", "Nagad", "Rocket"],
      receiveOptions: {
          Crypto: ["Litecoin"],
      },
    },
  /*
    {
      key: "pkrExchange",
      categoryId: "1386992150595633182",
      emoji: "<:pkr:1387326283045929030>",
      title: "PKR Exchanges",
      isPercentage: false,
      rates: {
        "PKR To Crypto": "320/$ | Any Amount",
        "Crypto To PKR": "270/$ | Any Amount",
      },
      raw: { p2c: 320, c2p: 270 },
      apps: ["JazzCash", "Easypaisa"],
    },
  */
  ],
};
