export default (client) => {
    console.log(`Logged in as ${client.user.tag}!`);
}