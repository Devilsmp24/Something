import {
  EmbedBuilder,
  StringSelectMenuBuilder,
  ActionRowBuilder,
  MessageFlags,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} from "discord.js";

const amountInputCache = new Map();

function getPaymentAppMenu(exchangeKey, client) {
  const exchange = client.config.exchangeRates.find(
    (e) => e.key === exchangeKey
  );
  if (!exchange || !exchange.apps?.length) return null;

  const appSelectMenu = new StringSelectMenuBuilder()
    .setCustomId("select_payment_app")
    .setPlaceholder("🧾 Select a payment app")
    .addOptions(
      exchange.apps.map((app) => ({
        label: app,
        value: `${exchangeKey}:${app.replace(/\s+/g, "_").toLowerCase()}`,
        description: `Pay using ${app}`,
      }))
    );

  return new ActionRowBuilder().addComponents(appSelectMenu);
}

function getReceiveOptionsMenu(exchangeKey, appId, client) {
  const exchange = client.config.exchangeRates.find(
    (e) => e.key === exchangeKey
  );
  if (!exchange || !exchange.receiveOptions) return null;
  const options = exchange.receiveOptions?.Crypto;
  if (!options?.length) return null;

  const menu = new StringSelectMenuBuilder()
    .setCustomId("select_receive_option")
    .setPlaceholder("📥 What You Want to Receive?")
    .addOptions(
      options.map((opt) => ({
        label: opt,
        value: `${exchangeKey}:${appId}:${opt
          .replace(/\s+/g, "_")
          .toLowerCase()}`,
        description: `Receive via ${opt}`,
      }))
    );

  return new ActionRowBuilder().addComponents(menu);
}

export default async (interaction, client) => {
  if (!interaction.isButton() && !interaction.isStringSelectMenu()) return;
  if (interaction.guildId !== client.config.guildId) return;
  const userId = interaction.user.id;
  const isAdmin = interaction.member.roles.cache.has(
    client.config.exchangerRoleId
  );

  if (interaction.customId === "create_ticket") {
    const embed = new EmbedBuilder()
      .setTitle("What will you be sending?")
      .setDescription(
        "Please select the type of payment method from the options below."
      )
      .setColor(client.config.exchangeEmbed.color)
      .setThumbnail(client.user.displayAvatarURL());

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId("select_payment_method")
      .setPlaceholder("💱 What You Will Be Sending?")
      .addOptions(
        client.config.exchangeRates.map((rate) => ({
          label: rate.title,
          value: rate.key,
          description: rate.title,
          emoji: rate.emoji,
        }))
      );

    await interaction.reply({
      embeds: [embed],
      components: [new ActionRowBuilder().addComponents(selectMenu)],
      flags: MessageFlags.Ephemeral,
    });
  } else if (interaction.customId === "select_payment_method") {
    const selectedKey = interaction.values[0];
    const selectedRate = client.config.exchangeRates.find(
      (rate) => rate.key === selectedKey
    );
    if (!selectedRate)
      return interaction.reply({
        content: "Invalid selection.",
        flags: MessageFlags.Ephemeral,
      });

    const embed = new EmbedBuilder()
      .setTitle(`${selectedRate.title}`)
      .setDescription(
        `You selected **${selectedRate.title}**.\nNow choose your **payment app**.`
      )
      .setColor(client.config.exchangeEmbed.color)
      .setThumbnail(client.user.displayAvatarURL());

    const appMenuRow = getPaymentAppMenu(selectedKey, client);

    await interaction.update({
      embeds: [embed],
      components: [appMenuRow],
      flags: MessageFlags.Ephemeral,
    });
  } else if (interaction.customId === "select_payment_app") {
    const [exchangeKey, appId] = interaction.values[0].split(":");
    const exchange = client.config.exchangeRates.find(
      (rate) => rate.key === exchangeKey
    );
    const appLabel = exchange?.apps.find(
      (app) => app.replace(/\s+/g, "_").toLowerCase() === appId
    );

    const embed = new EmbedBuilder()
      .setTitle(`${exchange.title}`)
      .setDescription(
        `Selected **${appLabel}** as your payment app.\nNow choose **what you would like to receive.**`
      )
      .setColor(client.config.exchangeEmbed.color)
      .setThumbnail(client.user.displayAvatarURL());

    const receiveMenuRow = getReceiveOptionsMenu(exchangeKey, appId, client);
    if (!receiveMenuRow)
      return interaction.update({
        content: "No valid receiving options available.",
        embeds: [],
        components: [],
        flags: MessageFlags.Ephemeral,
      });

    await interaction.update({
      embeds: [embed],
      components: [receiveMenuRow],
      flags: MessageFlags.Ephemeral,
    });
  } else if (interaction.customId === "select_receive_option") {
    const [exchangeKey, appId, receiveOptId] = interaction.values[0].split(":");
    const exchange = client.config.exchangeRates.find(
      (rate) => rate.key === exchangeKey
    );
    const appLabel = exchange?.apps.find(
      (app) => app.replace(/\s+/g, "_").toLowerCase() === appId
    );
    const crypto = exchange.receiveOptions?.Crypto.find(
      (c) => c.replace(/\s+/g, "_").toLowerCase() === receiveOptId
    );

    amountInputCache.set(userId, { exchangeKey, appId, crypto, amount: "0" });

    const embed = new EmbedBuilder()
      .setTitle(`${exchange.title}`)
      .setDescription(
        `You selected **${appLabel}** to send and will receive **${crypto}**.\nClick the buttons below to enter an amount.`
      )
      .addFields({ name: "Current Amount", value: "$0", inline: false })
      .setColor(client.config.exchangeEmbed.color)
      .setThumbnail(client.user.displayAvatarURL());

    const numpad = [
      ["1", "2", "3"],
      ["4", "5", "6"],
      ["7", "8", "9"],
      [".", "0", "clear"],
    ];
    const rows = numpad.map((row) =>
      new ActionRowBuilder().addComponents(
        row.map((label) =>
          new ButtonBuilder()
            .setCustomId(`numpad_${label}`)
            .setLabel(label === "clear" ? "Clear" : label)
            .setStyle(
              label === "clear" ? ButtonStyle.Danger : ButtonStyle.Secondary
            )
        )
      )
    );
    rows.push(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("submit_amount")
          .setLabel("Submit")
          .setStyle(ButtonStyle.Success)
      )
    );

    await interaction.update({
      embeds: [embed],
      components: rows,
      flags: MessageFlags.Ephemeral,
    });
  } else if (interaction.customId.startsWith("numpad_")) {
    const input = interaction.customId.split("numpad_")[1];
    const data = amountInputCache.get(userId);
    if (!data) return;

    let current = data.amount || "";
    if (input === "clear") current = "0";
    else {
      if (input === "." && current.includes("."))
        return interaction.deferUpdate();
      const [_, decimal] = current.split(".");
      if (decimal?.length >= 2 && input !== ".")
        return interaction.deferUpdate();
      current = current === "0" ? input : current + input;
    }

    data.amount = current;
    amountInputCache.set(userId, data);

    const embed = EmbedBuilder.from(interaction.message.embeds[0]);
    const updatedFields = embed.data.fields.map((f) =>
      f.name === "Current Amount"
        ? { name: "Current Amount", value: `$${current}`, inline: false }
        : f
    );
    embed.setFields(updatedFields);

    await interaction.update({
      embeds: [embed],
      components: interaction.message.components,
    });
  } else if (interaction.customId === "submit_amount") {
    const data = amountInputCache.get(userId);
    if (!data || data.amount === "0")
      return interaction.reply({
        content: "❌ You must enter a valid amount.",
        flags: MessageFlags.Ephemeral,
      });

    const embed = new EmbedBuilder()
      .setTitle("Only Transact Within Your Ticket!")
      .setDescription(
        "For your own safety ONLY transact within your ticket... anyone trying to get you to transact outside is likely trying to scam you!"
      )
      .setColor(client.config.exchangeEmbed.color);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel("Confirm")
        .setStyle(ButtonStyle.Success)
        .setCustomId("confirm_transaction"),
      new ButtonBuilder()
        .setLabel("Cancel")
        .setStyle(ButtonStyle.Danger)
        .setCustomId("cancel_transaction")
    );

    await interaction.reply({
      embeds: [embed],
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
  } else if (interaction.customId === "cancel_transaction") {
    amountInputCache.delete(userId);
    return interaction.update({
      embeds: [
        new EmbedBuilder()
          .setDescription("Transaction cancelled.")
          .setColor("Red"),
      ],
      components: [],
      flags: MessageFlags.Ephemeral,
    });
  } else if (interaction.customId === "confirm_transaction") {
    const data = amountInputCache.get(userId);
    if (!data) {
      return interaction.reply({
        content: "Session expired.",
        flags: MessageFlags.Ephemeral,
      });
    }

    const exchange = client.config.exchangeRates.find(
      (rate) => rate.key === data.exchangeKey
    );
    if (!exchange) {
      return interaction.reply({
        content: "Exchange not found.",
        flags: MessageFlags.Ephemeral,
      });
    }

    const sendingAmount = `₹${(
      parseFloat(data.amount) * exchange.raw.i2c
    ).toFixed(2)}`;
    const receivingAmount = `$${parseFloat(data.amount).toFixed(2)}`;

    const channel = await interaction.guild.channels.create({
      name: `ticket-${interaction.user.username}`.toLowerCase(),
      type: 0,
      parent: exchange.categoryId,
      permissionOverwrites: [
        { id: interaction.guild.roles.everyone, deny: ["ViewChannel"] },
        {
          id: userId,
          allow: ["ViewChannel", "SendMessages", "ReadMessageHistory"],
        },
        {
          id: client.config.exchangerRoleId,
          allow: ["ViewChannel", "SendMessages", "ManageMessages"],
        },
        {
          id: client.user.id,
          allow: ["ViewChannel", "SendMessages", "ManageChannels"],
        },
      ],
    });

    const summaryEmbed = new EmbedBuilder()
      .setTitle("📋 Exchange Summary")
      .setColor(client.config.exchangeEmbed.color)
      .addFields(
        { name: "Payment App", value: data.appId, inline: true },
        { name: "Receiving", value: "Crypto", inline: true },
        { name: "Sending Amount", value: sendingAmount, inline: true },
        { name: "Receiving Amount", value: receivingAmount, inline: true },
        { name: "Crypto", value: data.crypto, inline: true }
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("close_ticket")
        .setLabel("Close")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("claim_ticket")
        .setLabel("Claim")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("request_mm")
        .setLabel("Request MM")
        .setStyle(ButtonStyle.Success)
    );

    await channel.send({
      content: `Welcome <@${userId}>,\nOur Exchangers Will Be With You Soon. <@&${client.config.exchangerRoleId}>`,
      embeds: [summaryEmbed],
      components: [row],
    });

    await interaction.update({
      content: `✅ Your ticket has been created: <#${channel.id}>`,
      embeds: [],
      components: [],
      flags: MessageFlags.Ephemeral,
    });

    amountInputCache.delete(userId);
  }

  if (interaction.customId === "claim_ticket") {
    if (!isAdmin) {
      return interaction.reply({
        content: "Only staff members can claim the ticket.",
        flags: MessageFlags.Ephemeral,
      });
    }

    const channel = interaction.channel;
    if (!channel || channel.type !== 0) {
      return interaction.reply({
        content: "This command can only be used in a ticket channel.",
        flags: MessageFlags.Ephemeral,
      });
    }

    if (!channel.name.startsWith("✅")) {
      await channel.setName(`✅-${channel.name.replace(/^✅-/, "")}`);
    } else {
      interaction.reply({
        content: "This ticket is already claimed.",
        flags: MessageFlags.Ephemeral,
      });
    }

    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle("Ticket Claimed")
          .setColor("Green")
          .setDescription(
            `This ticket has been claimed by <@${interaction.user.id}>\n\nIf the mentioned amount is not correct, let the exchanger know.\n\nSending money more than the exchanger's limit is your responsibility. We won't care if you get scammed or something.`
          ),
        new EmbedBuilder()
          .setColor("Blue")
          .setTitle("Terms of Service")
          .setDescription(
            "By using this service, you agree to the following terms:\n1. Only transact within your ticket.\n2. We are not responsible for any scams or issues that arise from transactions outside of this platform.\n3. Ensure you understand the exchange rates and amounts before confirming any transaction.\nMust send screenshot after payment\nSend only from the app mentioned above."
          ),
      ],
      allowedMentions: { parse: [] },
    });
  }

  if (interaction.customId === "request_mm") {
    await interaction.reply({
      content: "❌ Middleman support is coming soon!",
      flags: MessageFlags.Ephemeral,
    });
  }

  if (interaction.customId === "close_ticket") {
    if (interaction.user.id !== userId && !isAdmin) {
      return interaction.reply({
        content: "Only the ticket owner or an admin can close this ticket.",
        flags: MessageFlags.Ephemeral,
      });
    }

    await interaction.channel.delete();
  }
};
