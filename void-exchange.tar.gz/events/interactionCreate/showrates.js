import { EmbedBuilder, MessageFlags } from "discord.js";

export default (interaction, client) => {
  if (interaction.customId !== "exchange_rate") return;
  if (interaction.guildId !== client.config.guildId) return;
  try {
    const config = client.config;
    function generateExchangeEmbedText() {
      return config.exchangeRates
        .map((entry) => {
          const header = `${entry.emoji} ${entry.title}\n`;
          const body = Object.entries(entry.rates)
            .map(([label, value]) => `> ${label}: ${value}`)
            .join("\n");

          return `**__${header}__**\n**${body}**`;
        })
        .join("\n");
    }

    const embed = new EmbedBuilder()
      .setTitle("Exchange Rates")
      .setColor(config.exchangeEmbed.color)
      .setDescription(generateExchangeEmbedText());

    interaction.reply({
      embeds: [embed],
      flags: MessageFlags.Ephemeral,
    });
    return true;
  } catch (error) {
    console.error("Error handling exchangerate interaction:", error);
    interaction.reply({
      content: "An error occurred while processing your request.",
      flags: MessageFlags.Ephemeral,
    });
  }
};
